# ModelReturn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**return** | **int** | property description  *_/ &#39; \&quot; &#x3D;end -- \\r\\n \\n \\r | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


