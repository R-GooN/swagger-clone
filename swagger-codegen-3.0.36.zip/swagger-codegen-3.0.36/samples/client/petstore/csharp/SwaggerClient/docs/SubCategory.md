# IO.Swagger.Model.SubCategory
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Category** | **AllOfSubCategoryCategory** |  | [optional] 
**Category2** | [**Category**](Category.md) |  | [optional] 
**Pets** | **List&lt;AllOfSubCategoryPetsItems&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

