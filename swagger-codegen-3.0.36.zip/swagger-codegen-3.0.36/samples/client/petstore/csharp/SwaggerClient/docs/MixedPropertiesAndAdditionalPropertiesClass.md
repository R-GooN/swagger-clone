# IO.Swagger.Model.MixedPropertiesAndAdditionalPropertiesClass
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Uuid** | **Guid?** |  | [optional] 
**DateTime** | **DateTime?** |  | [optional] 
**Map** | [**Dictionary&lt;string, Animal&gt;**](Animal.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

