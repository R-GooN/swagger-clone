# IO.Swagger.Model.MapTest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MapMapOfString** | **Dictionary&lt;string, Dictionary&lt;string, string&gt;&gt;** |  | [optional] 
**MapOfEnumString** | **Dictionary&lt;string, string&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

