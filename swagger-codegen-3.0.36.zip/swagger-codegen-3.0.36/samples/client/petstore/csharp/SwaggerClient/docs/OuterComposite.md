# IO.Swagger.Model.OuterComposite
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MyNumber** | [**decimal?**](BigDecimal.md) |  | [optional] 
**MyString** | **string** |  | [optional] 
**MyBoolean** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

