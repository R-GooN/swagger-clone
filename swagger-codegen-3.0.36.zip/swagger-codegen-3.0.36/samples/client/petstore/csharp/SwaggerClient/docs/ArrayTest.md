# IO.Swagger.Model.ArrayTest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ArrayOfString** | **List&lt;string&gt;** |  | [optional] 
**ArrayArrayOfInteger** | **List&lt;List&lt;long?&gt;&gt;** |  | [optional] 
**ArrayArrayOfModel** | **List&lt;List&lt;ReadOnlyFirst&gt;&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

