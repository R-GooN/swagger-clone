# IO.Swagger.Model.FakeJsonFormDataBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Param** | **string** | field1 | 
**Param2** | **string** | field2 | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

