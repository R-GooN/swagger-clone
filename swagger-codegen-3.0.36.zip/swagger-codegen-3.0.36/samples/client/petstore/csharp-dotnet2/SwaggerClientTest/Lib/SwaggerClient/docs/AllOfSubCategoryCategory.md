# IO.Swagger.Model.AllOfSubCategoryCategory
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Foo** | **bool?** |  | [optional] 
**Bar** | **int?** |  | [optional] 
**Beer** | **string** |  | [optional] 
**Drunk** | [**User**](User.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

