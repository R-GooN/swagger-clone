# IO.Swagger.Model.Cat
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Hunts** | **bool?** |  | [optional] 
**Age** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

