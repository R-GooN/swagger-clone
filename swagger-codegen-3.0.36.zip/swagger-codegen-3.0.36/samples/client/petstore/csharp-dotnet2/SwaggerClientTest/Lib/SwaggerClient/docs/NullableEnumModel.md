# IO.Swagger.Model.NullableEnumModel
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnumProp** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

