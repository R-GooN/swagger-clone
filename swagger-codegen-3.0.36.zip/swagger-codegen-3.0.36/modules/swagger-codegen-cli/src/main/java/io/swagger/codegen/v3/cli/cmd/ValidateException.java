package io.swagger.codegen.v3.cli.cmd;

/**
 * Created by takuro on 2017/05/02.
 */
public class ValidateException extends RuntimeException {
}
